package com.nimap.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nimap.model.Category;
import com.nimap.repository.CategoryRepository;
import com.nimap.service.CategoryService;


@RestController
@RequestMapping("/category")
public class CategoryController {
	
	@Autowired
	CategoryRepository categoryRepository;

	@Autowired
	CategoryService categoryService;
	
	@PostMapping("/save")
	public Category saveCategory(@RequestBody Category category) {
		return categoryService.saveCategory(category);
		
	}
	
	@GetMapping("/findAll")
	public List<Category> getAllCategories(){
		return categoryService.getAllCategories();
	}
	
	@GetMapping("/findById/{cid}")
	public Optional<Category> getById(@PathVariable Long cid){
		return categoryService.getById(cid);
	}
	
	@PutMapping("/update/{cid}")
	public Category updateCategory(@PathVariable Long cid, @RequestBody Category category) {
		return categoryService.updateCategory(cid, category);
	}

	@DeleteMapping("/deleteById/{cid}")
	public void deleteById(@PathVariable Long cid) {
		categoryService.deleteById(cid);
	}
	
}
