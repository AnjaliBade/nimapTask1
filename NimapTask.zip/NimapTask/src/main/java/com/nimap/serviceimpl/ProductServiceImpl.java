package com.nimap.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.nimap.model.Product;
import com.nimap.repository.ProductRepository;
import com.nimap.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	ProductRepository productRepository;

	@Override
	public Product saveProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public Optional<Product> getById(Long pid) {

		return productRepository.findById(pid);
	}

	@Override
	public List<Product> getAllProducts() {

		return productRepository.findAll();
	}

	@Override
	public Product updateProduct(Long pid, Product product) {

		return productRepository.save(product);
	}

	@Override
	public void deleteProductById(Long pid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Page<Product> getAllProduct(Pageable pageable) {
		return productRepository.findAll(pageable);
	}

//	@Override
//	public ResponseEntity<Page<Product>> getAllProducts(int page) {
//		PageRequest pageable =  PageRequest.of(page, 5);
//		Page<Product> product = productRepository.findAll(pageable);
//		return new ResponseEntity<>(product, HttpStatus.OK);
//	}

	
	
	

}
